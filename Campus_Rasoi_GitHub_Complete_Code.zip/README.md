# Campus Rasoi | Smart Canteen

A static GitHub Pages mini-project with an Indian canteen menu, cart, fake payment simulation, and past orders.

## Upload to your GitHub repository
1. Download and unzip `Campus_Rasoi_GitHub_Complete_Code.zip`.
2. Open your repository and upload `index.html`, `style.css`, and `app.js` into the **root** folder.
3. Commit the changes to your `main` branch.
4. In **Settings → Pages**, select `main` and `/(root)` if not already selected.
5. Open your GitHub Pages URL and refresh. If an old version appears, hard-refresh the browser.

## Features
- Add menu items and change quantities in the cart
- Demo checkout: UPI (Demo), Card (Demo), or Cash on Pickup
- Simulate successful or failed digital payments
- Order IDs, date, items, total and payment status
- Past orders saved in this browser using localStorage

## Important
This is a fake payment simulation. It does not contact a bank, UPI app, or payment gateway. Never enter real card details or UPI PINs. Past orders are saved only in this browser, not in a shared database. For a real multi-user project, add a backend API, database, authentication and a trusted payment provider. This starter uses food emoji illustrations; keep your existing photo assets if you want to add real dish images later.
